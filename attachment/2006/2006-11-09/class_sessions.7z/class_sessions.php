<?php /*
			���
			��\ 
			 �� �� . ��o O . ~~
��j�j�j�j�j�j�j�j�j�j�j�j�j�j�j�j�j�j�j�j�j�j�j�j�j�j�j��
�d�p�p��TITLE       : CLASS clsSessions				�p�p�g
�d�p����FILE        : class_sessions.php			  �p�g
�d�p����DESCRIPTION : To provide sessions utility  	  �p�g
�d�p				  for User options				  �p�g
�d�p����AUTHOR      : Peng Zhang  zpvip@msn.com		  �p�g
�d�p����WRITED   	: 2005 JUN 28					  �p�g
�d�p����MODIFIED  	: 2005 JUL 04					  �p�g
�d�p�p��REVISION 	: V1.0.0			            �p�p�g
��m�m�m�m�m�m�m�m�m�m�m�m�m�m�m�m�m�m�m�m�m�m�m�m�m�m�m��


*/
require_once ('includes/configure.php'); 
require_once (DIR_WS_CLASSES.'class_mysql.php');
class clsSessions {
	var $sess_life;
	
	
    //#-----------------------------------------------------------------
    //#---- FUNCTION :: clsSessions()
    //#---- DESCRIPTION  ::
    //#----      Initialize class clsSessions 
    //#---- INPUT ::
    //#----      none
    //#---- OUTPUT ::
    //#----      none
    //#-----------------------------------------------------------------
	function clsSessions() {
		$this->sess_life = get_cfg_var('session.gc_maxlifetime') ? get_cfg_var('session.gc_maxlifetime'):1440;
		session_set_save_handler(	array (& $this, "_sess_open"), 
									array (& $this, "_sess_close"),
									array (& $this, "_sess_read"),
									array (& $this, "_sess_write"),
									array (& $this, "_sess_destroy"),
									array (& $this, "_sess_gc")
								);
		return true;
    }
//---------------------------------------------------------------------------------------------------------------
	function _sess_open($save_path, $session_name) {
		return true;
	}

	function _sess_close() {
		return true;
	}

	function _sess_read($key) {
		$db = new clsMyDB(DB_SERVER, DB_SERVER_USERNAME, DB_SERVER_PASSWORD, DB_DATABASE, USE_PCONNECT);
		$db->connectDB();
		$value_query = $db->query("select value from " . TABLE_SESSIONS . " where sesskey = '" . $db->db_input($key) . "' and expiry > '" . time() . "'");
		$value = $db->fetch_array($value_query);
		if (isset($value['value'])) {
			return $value['value'];
		}
		return false;
	}

	function _sess_write($key, $val) {
		$db = new clsMyDB(DB_SERVER, DB_SERVER_USERNAME, DB_SERVER_PASSWORD, DB_DATABASE, USE_PCONNECT);
		$db->connectDB();
		$expiry = time() + $this->sess_life;
		$value = $val;
		$check_query = $db->query("select count(*) as total from " . TABLE_SESSIONS . " where sesskey = '" . $db->db_input($key) . "'");
		$check = $db->fetch_array($check_query);

		if ($check['total'] > 0) {
			return $db->query("update " . TABLE_SESSIONS . " set expiry = '" . $db->db_input($expiry) . "', value = '" . $db->db_input($value) . "' where sesskey = '" . $db->db_input($key) . "'");
		} else {
			return $db->query("insert into " . TABLE_SESSIONS . " values ('" . $db->db_input($key) . "', '" . $db->db_input($expiry) . "', '" . $db->db_input($value) . "')");
		}
	}

	function _sess_destroy($key) {
		$db = new clsMyDB(DB_SERVER, DB_SERVER_USERNAME, DB_SERVER_PASSWORD, DB_DATABASE, USE_PCONNECT);
		$db->connectDB();
		return $db->query("delete from " . TABLE_SESSIONS . " where sesskey = '" . $db->db_input($key) . "'");
	}

	function _sess_gc($maxlifetime) {
		$db = new clsMyDB(DB_SERVER, DB_SERVER_USERNAME, DB_SERVER_PASSWORD, DB_DATABASE, USE_PCONNECT);
		$db->connectDB();
		$db->query("delete from " . TABLE_SESSIONS . " where expiry < '" . time() . "'");
		return true;
	}
//---------------------------------------------------------------------------------------------------------------

//����Ϊһ��session����
	function my_session_start() {
		return session_start();
  	}
// --!
  	function my_session_register($variable) {
      		return session_register($variable);
  	}
// --!
  	function my_session_is_registered($variable) {
    	return session_is_registered($variable);
  	}
// --!
  	function my_session_unregister($variable) {
    	return session_unregister($variable);
  	}

  	function my_session_id($sessid = '') {
    	if (!empty($sessid)) {
      		return session_id($sessid);
    	} else {
      		return session_id();
    	}
  	}

  	function my_session_name($name = '') {
    	if (!empty($name)) {
      		return session_name($name);
    	} else {
      		return session_name();
    	}
  	}

  	function my_session_close() {
    	if (PHP_VERSION >= '4.0.4') {
      		return session_write_close();
    	} elseif (function_exists('session_close')) {
      		return session_close();
    	}
  	}

  	function my_session_destroy() {
    	return session_destroy();
  	}

  	function my_session_save_path($path = '') {
    	if (!empty($path)) {
      		return session_save_path($path);
    	} else {
      		return session_save_path();
    	}
  	}

  	function my_session_recreate() {
    	if (PHP_VERSION >= 4.1) {
      		$session_backup = $_SESSION;
			unset($_COOKIE[$this->my_session_name()]);
			$this->my_session_destroy();
			
			if (STORE_SESSIONS == 'mysql') {
				session_set_save_handler( array ("clsSessions", "_sess_open"), array ("clsSessions", "_sess_close"),array ("clsSessions", "_sess_read"),array ("clsSessions", "_sess_write"),array ("clsSessions", "_sess_destroy"),array ("clsSessions", "_sess_gc") );
			}

			$this->my_session_start();

			$_SESSION = $session_backup;
			unset($session_backup);
		}
	}

} // end class clsSessions
?>